﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TouchPoint
{
    public partial class PhotoChoose : PhoneApplicationPage
    {
        App app = Application.Current as App;

        public PhotoChoose()
        {
            InitializeComponent();
            Image.Source = app.bmp;
        }

        private void Recognize_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Wait.xaml", UriKind.Relative));
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
    }
}