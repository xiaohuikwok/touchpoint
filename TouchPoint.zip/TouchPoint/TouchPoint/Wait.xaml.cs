﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using TouchPoint.ServiceReference1;

namespace TouchPoint
{
    public partial class Wait : PhoneApplicationPage
    {
        App app = Application.Current as App;

        public Wait()
        {
            InitializeComponent();

            app.stream.Position = 0;
            byte[] bytes = new byte[app.stream.Length];
            app.stream.Read(bytes, 0, bytes.Length);

            WCFServiceClient client = new WCFServiceClient();
            client.RecognizeCompleted += client_RecognizeCompleted;
            client.RecognizeAsync(bytes);
        }

        void client_RecognizeCompleted(object sender, RecognizeCompletedEventArgs e)
        {
            try
            {
                app.text = e.Result;
                this.NavigationService.Navigate(new Uri("/Text.xaml", UriKind.Relative));
            }
            catch (Exception ep)
            {
                MessageBox.Show("未能连接服务器，请重试");
                this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
            }
        }
    }
}