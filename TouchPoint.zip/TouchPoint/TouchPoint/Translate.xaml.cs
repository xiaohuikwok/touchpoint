﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Windows.Phone.Speech.Synthesis;
using TouchPoint.ServiceReference2;

namespace TouchPoint
{
    public partial class Translate : PhoneApplicationPage
    {
        App app = Application.Current as App;
        SpeechSynthesizer speech = null;

        string strLngFrom = "en";
        string strLngTo = "zh-CHS";
        private string strTextToTranslate;

        public Translate()
        {
            InitializeComponent();
            //翻译部分
            if (app.text != "")
            {
                strTextToTranslate = app.text;
                String strTranslatorAccessURI = "https://datamarket.accesscontrol.windows.net/v2/OAuth2-13";
                System.Net.WebRequest req = System.Net.WebRequest.Create(strTranslatorAccessURI);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";
                IAsyncResult writeRequestStreamCallback =
                  (IAsyncResult)req.BeginGetRequestStream(new AsyncCallback(RequestStreamReady), req);
            }
            else ProgressBar.Visibility = Visibility.Collapsed;
        }

        private void RequestStreamReady(IAsyncResult ar)
        {
            // STEP 2: The request stream is ready. Write the request into the POST stream
            string clientID = "Touch_Point";  //ID
            string clientSecret = "MFrayNcNN0eF3VhYpJq2t4XKwfB8UlnlnJGJbfzjt1s="; //密钥
            String strRequestDetails = string.Format("grant_type=client_credentials&client_id={0}&client_secret={1}&scope=http://api.microsofttranslator.com", HttpUtility.UrlEncode(clientID), HttpUtility.UrlEncode(clientSecret));

            // note, this isn't a new request -- the original was passed to beginrequeststream, so we're pulling a reference to it back out. It's the same request

            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)ar.AsyncState;
            // now that we have the working request, write the request details into it
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(strRequestDetails);
            System.IO.Stream postStream = request.EndGetRequestStream(ar);
            postStream.Write(bytes, 0, bytes.Length);
            postStream.Close();
            // now that the request is good to go, let's post it to the server
            // and get the response. When done, the async callback will call the
            // GetResponseCallback function
            request.BeginGetResponse(new AsyncCallback(GetResponseCallback), request);
        }

        private void GetResponseCallback(IAsyncResult ar)
        {
            // STEP 3: Process the response callback to get the token
            // we'll then use that token to call the translator service
            // Pull the request out of the IAsynch result
            HttpWebRequest request = (HttpWebRequest)ar.AsyncState;
            // The request now has the response details in it (because we've called back having gotten the response
            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(ar);
            // Using JSON we'll pull the response details out, and load it into an AdmAccess token class (defined earlier in this module)
            // IMPORTANT (and vague) -- despite the name, in Windows Phone, this is in the System.ServiceModel.Web library,
            // and not the System.Runtime.Serialization one -- so you will need to have a reference to System.ServiceModel.Web
            try
            {
                System.Runtime.Serialization.Json.DataContractJsonSerializer serializer = new
                System.Runtime.Serialization.Json.DataContractJsonSerializer(typeof(AdmAccessToken));
                AdmAccessToken token =
                  (AdmAccessToken)serializer.ReadObject(response.GetResponseStream());

                string uri = "http://api.microsofttranslator.com/v2/Http.svc/Translate?text=" + System.Net.HttpUtility.UrlEncode(strTextToTranslate) + "&from=" + strLngFrom + "&to=" + strLngTo;
                System.Net.WebRequest translationWebRequest = System.Net.HttpWebRequest.Create(uri);
                // The authorization header needs to be "Bearer" + " " + the access token
                string headerValue = "Bearer " + token.access_token;
                translationWebRequest.Headers["Authorization"] = headerValue;
                // And now we call the service. When the translation is complete, we'll get the callback
                IAsyncResult writeRequestStreamCallback = (IAsyncResult)translationWebRequest.BeginGetResponse(new AsyncCallback(translationReady), translationWebRequest);
            }
            catch (Exception ex)
            {
                // Do nothing
            }
        }

        private void translationReady(IAsyncResult ar)
        {
            // STEP 4: Process the translation
            // Get the request details
            HttpWebRequest request = (HttpWebRequest)ar.AsyncState;
            // Get the response details
            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(ar);
            // Read the contents of the response into a string
            System.IO.Stream streamResponse = response.GetResponseStream();
            System.IO.StreamReader streamRead = new System.IO.StreamReader(streamResponse);
            string responseString = streamRead.ReadToEnd();
            // Translator returns XML, so load it into an XDocument
            // Note -- you need to add a reference to the System.Linq.XML namespace
            System.Xml.Linq.XDocument xTranslation = System.Xml.Linq.XDocument.Parse(responseString);
            string strTest = xTranslation.Root.FirstNode.ToString();
            // We're not on the UI thread, so use the dispatcher to update the UI
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                TranslateText.Text = strTest;
            });
            
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (speech != null)
                {
                    ReadText.Content = "发音";
                    speech.CancelAll();
                }
            }
            catch (OperationCanceledException ex)
            {
                //
            }
            this.NavigationService.GoBack();
        }

        private void BackMain_Click(object sender, RoutedEventArgs e)
        {
            app.text = "";
            try
            {
                if (speech != null)
                {
                    ReadText.Content = "发音";
                    speech.CancelAll();
                }
            }
            catch (OperationCanceledException ex)
            {
                //
            }
            
            this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }

        private async void ReadText_Click(object sender, RoutedEventArgs e)
        {
            try
            {
            //发音部分
            if (ReadText.Content.Equals("发音"))
            {
                ReadText.Content = "停止";
                string filterLanguage = "";
                speech = new SpeechSynthesizer();

                filterLanguage = "zh-CN";

                //Query for a voice that speaks French.
                IEnumerable<VoiceInformation> voices = from voice in InstalledVoices.All
                                                       where voice.Language == filterLanguage
                                                       select voice;

                // Set the voice as identified by the query.
                speech.SetVoice(voices.ElementAt(0));

                // Count in French.
                await speech.SpeakTextAsync(TranslateText.Text);
            }
            
                if (ReadText.Content.Equals("停止"))
                {
                    ReadText.Content = "发音";
                    speech.CancelAll();
                }
            }
            catch (OperationCanceledException ex)
            {

            }
            
            
        }
    }
    public class AdmAccessToken
    {
        public string access_token { get; set; }
        public string token_type { get; set; }
        public string expires_in { get; set; }
        public string scope { get; set; }
    }
}