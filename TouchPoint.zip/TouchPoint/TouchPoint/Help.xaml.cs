﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TouchPoint
{
    public partial class Help : PhoneApplicationPage
    {
        public Help()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            HelpText.Text = 
                "1.  本应用可从带有印刷体英文的图片识别出文本\n" + 
                "2.  图片可从相机拍摄或者图片库选取\n" + 
                "3.  识别出的文本可进行翻译和朗读\n" + 
                "4.  若识别有不正确的地方，可手动进行修改\n" +
                "5.  可选择\"手动\"来进行手动输入文本";
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
    }
}