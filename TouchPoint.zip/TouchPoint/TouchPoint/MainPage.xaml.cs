﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;

namespace TouchPoint
{
    public partial class MainPage : PhoneApplicationPage
    {
        PhotoChooserTask photoChoose = new PhotoChooserTask();
        CameraCaptureTask camera = new CameraCaptureTask();
        // 构造函数
        public MainPage()
        {
            InitializeComponent();

            // 将 listbox 控件的数据上下文设置为示例数据
            DataContext = App.ViewModel;
            DataContext = App.ViewModel;
            photoChoose.Completed += photoChoose_Completed;
            camera.Completed += photoChoose_Completed;
        }

        void photoChoose_Completed(object sender, PhotoResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                App app = Application.Current as App;
                app.stream = e.ChosenPhoto;
                app.bmp.SetSource(e.ChosenPhoto);
                this.NavigationService.Navigate(new Uri("/PhotoChoose.xaml", UriKind.Relative));
            }
        }

        // 为 ViewModel 项加载数据
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (!App.ViewModel.IsDataLoaded)
            {
                App.ViewModel.LoadData();
            }
        }

        private void Camera_Click(object sender, RoutedEventArgs e)
        {
            camera.Show();
        }

        private void Photo_Click(object sender, RoutedEventArgs e)
        {
            photoChoose.Show();
        }

        private void Type_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Text.xaml", UriKind.Relative));
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Help.xaml", UriKind.Relative));
        }
    }
}