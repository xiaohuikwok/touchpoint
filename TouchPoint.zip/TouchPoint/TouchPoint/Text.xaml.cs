﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Windows.Phone.Speech.Synthesis;

namespace TouchPoint
{
    public partial class Text : PhoneApplicationPage
    {
        App app = Application.Current as App;
        SpeechSynthesizer speech = null;

        public Text()
        {
            InitializeComponent();
            TextBox.Text = app.text;
        }

        private void Translate_Click(object sender, RoutedEventArgs e)
        {
            app.text = TextBox.Text;
            try
            {
                if (speech != null)
                {
                    Read.Content = "发音";
                    speech.CancelAll();
                }
            }
            catch (OperationCanceledException ex)
            {
                //
            }
            this.NavigationService.Navigate(new Uri("/Translate.xaml", UriKind.Relative));
        }

        private async void Read_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Read.Content.Equals("发音"))
                {
                    Read.Content = "停止";
                    string filterLanguage = "";
                    speech = new SpeechSynthesizer();
                    /*switch (strLngTo)
                      {
                          case "zh-CHS":
                              {
                                  filterLanguage = "zh-CN";
                                  break;
                              }
                          case "en":
                              {
                                  filterLanguage = "en-US";
                                  break;
                              }

                          default:
                              {
                                  filterLanguage = "zh-CN";
                                  break;
                              }

                      }
                      */

                    filterLanguage = "en-US";

                    //Query for a voice that speaks French.
                    IEnumerable<VoiceInformation> voices = from voice in InstalledVoices.All
                                                           where voice.Language == filterLanguage
                                                           select voice;

                    // Set the voice as identified by the query.
                    speech.SetVoice(voices.ElementAt(0));

                    // Count in French.
                    await speech.SpeakTextAsync(TextBox.Text);
                }

                if (Read.Content.Equals("停止"))
                {
                    Read.Content = "发音";
                    speech.CancelAll();
                }
            }
            catch (OperationCanceledException ex)
            {
                //
            }
            
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            app.text = "";
            try
            {
                if (speech != null)
                {
                    Read.Content = "发音";
                    speech.CancelAll();
                }
            }
            catch (OperationCanceledException ex)
            {
                //
            }
            
            this.NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }

    }
}